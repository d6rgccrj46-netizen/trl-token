# TRL v1 launch checklist

## Testnet
1. Create a dedicated deployer wallet.
2. Fund it only with testnet ETH.
3. Copy `.env.example` to `.env` and fill the RPC/private key locally.
4. `npm install`
5. `npm test`
6. `npm run compile`
7. `npm run deploy:testnet`
8. Record the TRL contract address.
9. Verify the contract on BaseScan.
10. Test transfer, approve and transferFrom with two wallets.
11. Deploy `TRLVesting` with a test beneficiary and schedule.
12. Test releasable/release at and after the cliff.

## Mainnet gate
Do not proceed until:
- source is reviewed;
- tests pass;
- contract bytecode is verified;
- token distribution is reconciled;
- treasury is separated from the deployer;
- founder allocation is placed in vesting;
- legal/tax requirements for the jurisdictions involved are checked;
- public disclosures are prepared.

## Mainnet
1. Use a fresh production deployer wallet.
2. Fund it with only the ETH needed for deployment.
3. Deploy TRL once.
4. Verify source immediately.
5. Deploy founder vesting.
6. Transfer exactly 100,000,000 TRL to the vesting wallet.
7. Transfer remaining allocations to their published wallets/multisig.
8. Reconcile balances against the 1B supply.
9. Only then create the public liquidity pool.
10. Publish contract, wallet, vesting and liquidity addresses.

Never publish a private key, seed phrase, or `.env` file.

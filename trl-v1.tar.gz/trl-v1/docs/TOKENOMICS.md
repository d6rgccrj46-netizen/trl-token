# TRL v1 Tokenomics

Total supply: 1,000,000,000 TRL

- Liquidity: 300,000,000 (30%)
- Community: 250,000,000 (25%)
- Treasury: 150,000,000 (15%)
- Founder/Team: 100,000,000 (10%)
- Marketing: 100,000,000 (10%)
- Partnerships: 50,000,000 (5%)
- Airdrop: 50,000,000 (5%)

Token properties:
- Fixed supply
- No mint function
- No transfer tax
- No blacklist
- No pause function
- No upgradeable proxy

Founder allocation should be placed in TRLVesting and its address published before any public launch.

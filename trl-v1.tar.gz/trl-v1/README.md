# TRL v1 — Tarlan

Fixed-supply ERC-20 starter project for Base / Base Sepolia.

## Token
- Name: Tarlan
- Symbol: TRL
- Supply: 1,000,000,000
- Decimals: 18
- Mint after deployment: No
- Tax: 0%
- Upgradeability: No

## Install

```bash
npm install
cp .env.example .env
```

Fill `.env` locally. Never commit it.

## Test

```bash
npm test
npm run compile
```

## Base Sepolia

Set `BASE_SEPOLIA_RPC_URL` and `PRIVATE_KEY`, then:

```bash
npm run deploy:testnet
```

Copy the printed contract address into `TRL_ADDRESS` and verify:

```bash
npm run verify:testnet
```

## Founder vesting

Set:

- `FOUNDER_BENEFICIARY` — founder wallet
- `VESTING_START_TIMESTAMP` — published Unix timestamp

Then:

```bash
npm run deploy:vesting:testnet
```

The planned founder allocation is 100,000,000 TRL. After deploying the vesting wallet, transfer exactly that amount of TRL to it.

## Mainnet

Do not deploy to mainnet until the testnet checklist in `docs/LAUNCH.md` is complete and the public/legal requirements have been reviewed.

## Important

This repository is a technical starter kit, not an audit and not legal or financial advice. A public token launch can create regulatory, tax, consumer-protection and disclosure obligations depending on the jurisdictions and distribution model.

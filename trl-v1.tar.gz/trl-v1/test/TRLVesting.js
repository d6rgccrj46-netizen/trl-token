const { expect } = require("chai");
const { ethers } = require("hardhat");

const DAY = 24 * 60 * 60;

describe("TRLVesting", function () {
  it("has the expected cliff and duration", async function () {
    const [beneficiary] = await ethers.getSigners();
    const now = (await ethers.provider.getBlock("latest")).timestamp;
    const start = now + DAY;
    const duration = 24 * 30 * DAY;
    const cliff = 3 * 30 * DAY;

    const Vesting = await ethers.getContractFactory("TRLVesting");
    const vesting = await Vesting.deploy(beneficiary.address, start, duration, cliff);
    await vesting.waitForDeployment();

    expect(await vesting.start()).to.equal(start);
    expect(await vesting.duration()).to.equal(duration);
    expect(await vesting.cliff()).to.equal(start + cliff);
  });
});

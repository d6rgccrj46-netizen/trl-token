const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("TRL", function () {
  it("has fixed 1B supply and correct metadata", async function () {
    const [owner] = await ethers.getSigners();
    const TRL = await ethers.getContractFactory("TRL");
    const token = await TRL.deploy();
    await token.waitForDeployment();

    expect(await token.name()).to.equal("Tarlan");
    expect(await token.symbol()).to.equal("TRL");
    expect(await token.decimals()).to.equal(18);
    expect(await token.totalSupply()).to.equal(ethers.parseEther("1000000000"));
    expect(await token.balanceOf(owner.address)).to.equal(ethers.parseEther("1000000000"));
  });

  it("transfers normally", async function () {
    const [owner, user] = await ethers.getSigners();
    const TRL = await ethers.getContractFactory("TRL");
    const token = await TRL.deploy();
    await token.waitForDeployment();

    await token.transfer(user.address, ethers.parseEther("1000"));
    expect(await token.balanceOf(user.address)).to.equal(ethers.parseEther("1000"));
  });

  it("has no mint function or owner function", async function () {
    const TRL = await ethers.getContractFactory("TRL");
    const functionNames = TRL.interface.fragments
      .filter((x) => x.type === "function")
      .map((x) => x.name);

    expect(functionNames).to.not.include("mint");
    expect(functionNames).to.not.include("owner");
  });
});

const { ethers } = require("hardhat");
require("dotenv").config();

async function main() {
  const beneficiary = process.env.FOUNDER_BENEFICIARY;
  if (!beneficiary) throw new Error("Set FOUNDER_BENEFICIARY in .env");

  // Start is supplied explicitly so the published vesting schedule is deterministic.
  const start = Number(process.env.VESTING_START_TIMESTAMP);
  if (!start) throw new Error("Set VESTING_START_TIMESTAMP in .env");

  const duration = 21 * 30 * 24 * 60 * 60; // approx. 21 months
  const cliff = 3 * 30 * 24 * 60 * 60;      // approx. 3 months

  const Vesting = await ethers.getContractFactory("TRLVesting");
  const vesting = await Vesting.deploy(beneficiary, start, duration, cliff);
  await vesting.waitForDeployment();

  console.log("TRLVesting deployed:", await vesting.getAddress());
  console.log("Beneficiary:", beneficiary);
  console.log("Start:", start);
  console.log("Duration:", duration);
  console.log("Cliff:", cliff);
  console.log("Founder allocation:", "100,000,000 TRL");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deployer:", deployer.address);
  console.log("Balance:", ethers.formatEther(await ethers.provider.getBalance(deployer.address)), "ETH");

  const TRL = await ethers.getContractFactory("TRL");
  const token = await TRL.deploy();
  await token.waitForDeployment();

  const address = await token.getAddress();
  console.log("TRL deployed:", address);
  console.log("Total supply:", ethers.formatUnits(await token.totalSupply(), 18), "TRL");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

const hre = require("hardhat");
require("dotenv").config();

async function main() {
  const token = process.env.TRL_ADDRESS;
  if (!token) throw new Error("Set TRL_ADDRESS in .env");
  await hre.run("verify:verify", { address: token, constructorArguments: [] });
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

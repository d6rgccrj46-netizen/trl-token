// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {VestingWalletCliff} from "@openzeppelin/contracts/finance/VestingWalletCliff.sol";

/// @title TRL Founder Vesting
/// @notice Standard OpenZeppelin linear vesting with a 3-month cliff.
contract TRLVesting is VestingWalletCliff {
    constructor(
        address beneficiary,
        uint64 startTimestamp,
        uint64 durationSeconds,
        uint64 cliffSeconds
    ) VestingWalletCliff(beneficiary, startTimestamp, durationSeconds, cliffSeconds) {}
}

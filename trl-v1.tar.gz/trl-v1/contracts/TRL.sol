// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @title Tarlan (TRL)
/// @notice Fixed-supply ERC-20 token. No owner, mint, tax, blacklist or upgradeability.
contract TRL is ERC20 {
    uint256 public constant MAX_SUPPLY = 1_000_000_000 ether;

    constructor() ERC20("Tarlan", "TRL") {
        _mint(msg.sender, MAX_SUPPLY);
    }
}
